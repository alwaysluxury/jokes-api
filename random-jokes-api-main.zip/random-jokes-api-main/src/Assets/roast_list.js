const roast = [
    {
        roasts: "Mirrors can't talk. Luckly for you, they can't laugh either.",
    },
    {
        roasts: "If i had a face like yours, I'd sue my parents.",
    },
    {
        roasts: "You must have been born on a highway cos' that's where most accidents happen.",
    },
    {
        roasts: "If laughter is the best medicine, your face must be curing the world.",
    },
    {
        roasts: "if i wanted to kill myself i'd climb your ego and jump to your IQ.",
    },
    {
        roasts: "You’re the reason God created the middle finger.",
    },
    {
        roasts: "If your brain was dynamite, there wouldn’t be enough to blow your hat off.",
    },
    {
        roasts: "Your kid is so annoying, he makes his Happy Meal cry.",
    },
    {
        roasts: "You have so many gaps in your teeth it looks like your tongue is in jail.",
    },
    {
        roasts: "Your secrets are always safe with me. I never even listen when you tell me them.",
    },
    {
        roasts: "Hold still. I’m trying to imagine you with personality.",
    },
    {
        roasts: "Your face makes onions cry.",
    },

    {
        roasts: "You look so pretty. Not at all gross, today.",
    },
    {
        roasts: "I’m not a nerd, I’m just smarter than you.",
    },
    {
        roasts: "I’m not insulting you, I’m describing you.",
    },
    {
        roasts: "Don’t worry about me. Worry about your eyebrows.",
    },
    {
        roasts: "You are the human version of period cramps.",
    },
    {
        roasts: "I may love to shop but I will never buy your bull.",
    },
    {
        roasts: "Child, I’ve forgotten more than you ever knew.",
    },
    {
        roasts: "I see no evil, and I definitely don’t hear your evil.",
    },
    {
        roasts: "I forgot the world revolves around you. My apologies, how silly of me.",
    },
    {
        roasts: " It’s impossible to underestimate you.",
    },
    {
        roasts: "I thought of you today. It reminded me to take out the trash.",
    },
    {
        roasts: "You are like a cloud. When you disappear it’s a beautiful day.",
    },
    {
        roasts: "OH MY GOD! IT SPEAKS!",
    },
    {
        roasts: "I love what you’ve done with your hair. How do you get it to come out of your nostrils like that?",
    },
    {
        roasts: "I may love to shop but I will never buy your bull.",
    },
    {
        roasts: "Don’t worry, the first 40 years of childhood are always the hardest.",
    },
    {
        roasts: "“It looks like she went into Claire’s Boutique, fell on a sale rack and said, ‘I’ll take it!’”",
    },
    {
        roasts: "“Is your ass jealous of the amount of sh*t that comes out of your mouth?”",
    },
    {
        roasts: "“Go back to Party City, where you belong!”",
    },
    {
        roasts: "“Where’d you get your outfits, girl, American Apparently Not?”",
    },
    {
        roasts: " “Impersonating Beyoncè is not your destiny, child.” ",
    },
    {
        roasts: "“Don’t get bitter, just get better.”",
    },
    {
        roasts: "Child, I’ve forgotten more than you ever knew.",
    },
    {
        roasts: "You just might be why the middle finger was invented in the first place.",
    },
    {
        roasts: "I know you are but what am I?",
    },
    {
        roasts: "I see no evil, and I definitely don’t hear your evil.",
    },
    {
        roasts: "When you look in the mirror, say hi to the clown you see in there for me, would ya?",
    },
    {
        roasts: "Bye, hope to see you never.",
    },
    {
        roasts: "Complete this sentence for me: “I never want to see you ————!”",
    },
    {
        roasts: "Remember that time you were saying that thing I didn’t care about? Yeah… that is now.",
    },
    {
        roasts: "I was today years old when I realized I didn’t like you.",
    },
    {
        roasts: "N’Sync said it best, “BYE, BYE, BYE”",
    },
    {
        roasts: "Wish I had a flip phone so I could slam it shut on this conversation.",
    },
    {
        roasts: "How many licks ’till I get to the interesting part of this conversation?",
    },
    {
        roasts: "Wow, your maker really didn’t waste time giving you a personality, huh?",
    },
    {
        roasts: "You cute. Like my dog. He also always chases his tail for entertainment.",
    },
    {
        roasts: "Somebody you’ll go far… and I really hope you stay there.",
    },
    {
        roasts: "Oh, I’m sorry. Did the middle of my sentence interrupt the beginning of yours?",
    },
    {
        roasts: "You bring everyone so much joy! You know, when you leave the room. But, still.",
    },
    {
        roasts: "Oops, my bad. I could’ve sworn I was dealing with an adult.",
    },
    {
        roasts: "Did I invite you to the barbecue? Then why are you all up in my grill?",
    },
    {
        roasts: "I’m an acquired taste. If you don’t like me, acquire some taste.",
    },
    {
        roasts: "Somewhere out there is a tree tirelessly producing oxygen for you. You owe it an apology.",
    },
    {
        roasts: "Yeah? Well, you smell like hot dog water.",
    },
    {
        roasts: "*Thumbs down*",
    },
    {
        roasts: "That sounds like a you problem.",
    },
    {
        roasts: "Beauty is only skin deep, but ugly goes clean to the bone.",
    },
    {
        roasts: "Oh, you don’t like being treated the way you treat me? That must suck.",
    },
    {
        roasts: "“I’ve been called worse things by better men.”",
    },
    {
        roasts: "Well, the jerk store called and they’re running out of you. (A Seinfeld classic)",
    },
    {
        roasts: "“What, like it’s hard?”",
    },
    {
        roasts: "Sorry not sorry.",
    },
    {
        roasts: "I’m busy right now, can I ignore you another time?",
    },
    {
        roasts: "If you have a problem with me, write the problem on a piece of paper, fold it, and shove it up your ass.",
    },
    {
        roasts: "You have an entire life to be an idiot. Why not take today off?",
    },
    {
        roasts: "No matter how much a snake sheds its skin, it’s still a snake.",
    },
    {
        roasts: " Some people are like slinkies — not really good for much but bring a smile to your face when pushed down the stairs.",
    },
    {
        roasts: "You’re the reason this country has to put directions on shampoo.",
    },
    {
        roasts: "Of course I’m talking like an idiot… how else could you understand me?",
    },
    {
        roasts: "Are you almost done with all of this drama? Because I need an intermission.",
    },



];

exports.roast = roast;