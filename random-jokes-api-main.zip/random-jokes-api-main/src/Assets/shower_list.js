const shower = [
    {
       thought: "The Truman show probably could’ve ended much earlier if Truman just said the n-word",
    },
    {
       thought: "Dora the Explorer is visually impaired and Boots is her service animal because she never sees what she’s looking for unless Boots (and viewers) helps her out",
    },
    {
       thought: "Harry Potter books would’ve ended a lot sooner if Voldemort tried to kill baby Harry with a large pillow instead of magic",
    },
    {
       thought: "Voldemort spent most of book 1 grading Defense Against the Dark Arts essays and at some point he had to give an Outstanding to Hermione",
    },

    {
       thought: "Captain isn't the highest rank, so there could be a Major Obvious who is even better at pointing out things everyone already knows.",
    },
    {
       thought: "There's nothing as tranquil as the brief moment of silence when going under an overpass in the rain.",
    },
    {
       thought: "Read and Lead can be rhymed twice",
    },
    {
       thought: "If you do a dance with enough confidence, people will love it no matter how stupid it is.",
    },
    {
       thought: "Anxious people often don't respond to emails/texts not because they forget to reply, but because remembering to respond is the reason it takes so long.",
    },
    {
       thought: "You’ll never understand how much your parents love you until you have kids of your own but then the cycle continues with your own children",
    },
    {
       thought: "There's always just as much sky below us as above, there just happens to be a planet blocking the view.",
    },
    {
       thought: "Alcoholism and drug abuse make more sense when you join the workforce.",
    },
    {
       thought: "The fact that extremely loud sound can kill you makes those vibrating air molecules much more dangerous than we think.",
    },
    {
       thought: "You have to pay more to add something to a sandwich, but you don’t pay less when you order it without a set component",
    },
    {
       thought: `Somehow essential oils went from "relaxing lavender scent" to "cures cancer"`,
    },
    {
       thought: "The 2 Cs in THICC looks like ass cheeks.",
    },
    {
       thought: "In 20 or 30 years we will be nostalgic about raid shadow legends ads",
    },
    {
       thought: "In the marvel cinematic universe, there would likely be “Snap-Deniers” that swear it’s all a conspiracy/cover up.",
    },
    {
       thought: `How to delete your browser history" is likely the least common search to show up in the search history in proportion to how frequent it is.`,
    },
    {
       thought: "The majority of living Britons have seen only one person on the British throne in their lifetime.",
    },
    {
       thought: "Even if Life did come with an instruction manual, most people wouldn't read it",
    },
    {
        thought: "The most unbelievable thing about Star Wars is that Anakin, a 9 year old boy, made C3PO and no bugs have ever showed up in over 40 years."
    },
    {
        thought: "There are probably a lot of answering machines sitting in storage which hold the only voice recordings for people who have passed away"
     },
     {
        thought: "All furniture and mattress stores exist in a binary state of either “grand opening” or “Going out of business liquidation sale”"
     },
     {
        thought: "Naming a baby makes you think of all the people you have disliked throughout your life"
     },
     {
        thought: "Mermaids would probably have thick abs from constantly doing dolphin kicks and/or swimming in general."
     },
     {
        thought: "Considering how many 90s kids were obsessed with Nirvana, it is surprising there aren't tons of teenagers and 20 somethings named Kurt."
     },
     {
        thought: "Before computers, having to remember multiple passwords probably meant you had a pretty interesting life."
     },
     {
        thought: "A carpenter is both a breadwinner and a homemaker."
     },
     {
        thought: "Many people are not working remotely. They are living at work"
     },
     {
        thought: "Considering how long his fame has lasted, Shakespeare did an incredibly small amount of promotional work"
     },
     {
        thought: "Boomers are more worried about people playing games, in which you are actively participating and your brain is engaged, than they are television, in which you are doing absolutely nothing and you aren't required to think."
     },
     {
        thought: "Every butt smack sounds different..given the butt, it's density, shape, and force of the smack."
     },
     {
        thought: "It's kinda funny that in popular culture vanilla is thought of as white and mild, when in fact the vanilla bean is dark black and very strong tasting, there's only a small amount in a tub of ice cream."
     },
     {
        thought: "A kingdom established by Alexander the Adequate would probably still be around."
     },
     {
        thought: "If superpower healing followed the rules of chemistry, re-growing a chopped off limb would easily take +100,000 calories, necessitating that only obese superheroes could undertake the process as all low BMI people would enter into a hypoglycemic coma."
     },
     {
        thought: "Tupperware probably makes most of its money replacing stuff stained by tomatoes."
     },
     {
        thought: "Not giving a shit would actually solve a lot of your problems. But not giving a shit probably created a lot of them, too."
     },
     {
        thought: "Your attention span is a product that companies fight for"
     },
     {
        thought: "Evil AI robots are portrayed as humanoid Skynet terminators but they'd probably just be waterproof micro-drones that enter everyone's house through the sewers to finish us off while we sleep."
     },
     {
        thought: "Reincarnation technically can exist, as the molecules that make up your body, might someday be passed on to make up the body of another organism, perhaps even a human."
     },
     {
        thought: "The most amazing thing about marvel movies/comics isn't the powers or fantastical adventurers but rather how the entire universe knows how to speak and understand the English language"
     },
     {
        thought: "Ever since the launch of the first space station, the place with the highest IQ per capita is no longer on earth."
     },
     {
        thought: "Eventually some asshole will introduce spiders to Mars"
     },
     {
        thought: "Hogwarts is probably the only school that can separate evil kids into groups then act all surprised when one of them turns out to be evil."
     },
     {
        thought: "A big milestone of male maturity is when you stop putting up with annoying girls just because they are hot"
     },
     {
        thought: "Garbagemen know what houses have alcoholics"
     },
     {
        thought: "We all got so used to the moon that we often forget how cool it actually is to casually see a natural satellite floating in space."
     },
     {
        thought: "Everybody is made out of food."
     },
     {
        thought: "Since it consists full of gas molecules, atmosphere is actually the sea that only birds, insects and bats can swim in, and humans are shrimp-like animals that live on the sea floor."
     },

]

exports.shower = shower;