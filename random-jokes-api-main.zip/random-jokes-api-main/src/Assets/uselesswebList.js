const web = [
    {
        url: "http://www.biglongnow.com/",
    },
    {
        url: "http://burymewithmymoney.com/",
    },
    {
        url: "http://dogs.are.the.most.moe/",
    },
    {
        url: "http://cat-bounce.com/",
    },
    {
        url: "http://www.partridgegetslucky.com/",
    },
    {
        url: "http://www.trypap.com/",
    },
    {
        url: "http://chrismckenzie.com/",
    },
    {
        url: "http://www.rrrgggbbb.com/",
    },
    {
        url: "http://www.trashloop.com/",
    },

    {
        url: "http://randomcolour.com/",
    },
    {
        url: "http://onemillionlols.com/",
    },
    {
        url: "http://beesbeesbees.com/",
    },
    {
        url: "http://dontevenreply.com/",
    },
    {
        url: "http://www.fallingfalling.com/",
    },
    {
        url: "http://eelslap.com/",
    },
    {
        url: "http://weirdorconfusing.com/",
    },
    {
        url: "http://intotime.com/",
    },
    {
        url: "https://pointerpointer.com/",
    },
    {
        url: "http://www.wutdafuk.com/",
    },
    {
        url: "http://r33b.net/",
    },
    {
        url: "http://pixelsfighting.com/",
    },
    {
        url: "http://www.sanger.dk/",
    },
    {
        url: "http://www.infinitething.com/",
    },
    {
        url: "https://findtheinvisiblecow.com/",
    },
    {
        url: "https://theuselessweb.com/",
    },
    {
        url: "http://hackertyper.com/",
    },
    {
        url: "https://www.pointerpointer.com/",
    },
    {
        url: "http://www.staggeringbeauty.com/",
    },
    {
        url: "http://www.shadyurl.com/",
    },
    {
        url: "http://dontevenreply.com/",
    },
    {
        url: "http://shutupandtakemymoney.com/",
    },
    {
        url: "https://en.wikipedia.org/wiki/List_of_individual_dogs",
    },
    {
        url: "http://www.drivemeinsane.com/",
    },
    {
        url: "http://apod.nasa.gov/apod/astropix.html",
    },
    {
        url: "https://www.duolingo.com/",
    },
    {
        url: "http://hubski.com/",
    },
    {
        url: "http://lizardpoint.com/",
    },
    {
        url: "http://www.musictheory.net/",
    },
    {
        url: "http://www.sleepyti.me/",
    },
    {
        url: "http://www.whatshouldireadnext.com/",
    },
    {
        url: "https://www.onread.com/",
    },
    {
        url: "http://weavesilk.com/",
    },
    {
        url: "http://www.ineedaprompt.com/",
    },
    {
        url: "http://www.thisissand.com/",
    },
    {
        url: "https://pokemonshowdown.com/",
    },
    {
        url: "https://snes.party/",
    },
    {
        url: "http://www.sporcle.com/",
    },
    {
        url: "http://www.poptropica.com/",
    },
    {
        url: "http://koalabeast.com/",
    },
    {
        url: "http://koalabeast.com/",
    },
    {
        url: "http://orteil.dashnet.org/cookieclicker/",
    },
    {
        url: "http://www.foddy.net/2010/10/qwop/",
    },
    {
        url: "https://habitrpg.com/static/front",
    },
    {
        url: "http://www.flashbynight.com/",
    },

    {
        url: "http://www.partycloud.fm/",
    },
    {
        url: "http://youarelistening.to/",
    },
    {
        url: "http://www.incredibox.com/",
    },
    {
        url: "http://www.doihaveadeadpixel.com/",
    },
];

exports.web = web;