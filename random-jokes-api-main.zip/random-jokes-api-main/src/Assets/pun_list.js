const pun = [
    {
        joke: "Light travels faster than sound. That's why some people appear bright until you hear them speak",
    },
    {
        joke: "I was wondering why the ball was getting bigger. Then it hit me",
    },
    {
        joke: "I have a few jokes about unemployed people, but none of them work",
    },
    {
        joke: '"I have a split personality," said Tom, being frank.',
    },
    {
        joke: "How do you make holy water? You boil the hell out of it",
    },
    {
        joke: "I Renamed my iPod The Titanic, so when I plug it in, it says “The Titanic is syncing.”",
    },
    {
        joke: "When life gives you melons, you're dyslexic",
    },
    {
        joke: "Last night, I dreamed I was swimming in an ocean of orange soda. But it was just a Fanta sea",
    },
    {
        joke: "Will glass coffins be a success? Remains to be seen",
    },
    {
        joke: "Two windmills are standing in a wind farm. One asks, “What’s your favorite kind of music?” The other says, “I’m a big metal fan.”",
    },
    {
        joke: "What’s the difference between a hippo and a zippo? One is really heavy and the other is a little lighter",
    },
    {
        joke: "Did you hear about the guy whose whole left side was cut off? He’s all right now",
    },
    {
        joke: "I can’t believe I got fired from the calendar factory. All I did was take a day off",
    },
    {
        joke: "The man who survived pepper spray and mustard gas is now a seasoned veteran",
    },
    {
        joke: "My dad farted in an elevator, it was wrong on so many levels",
    },
    {
        joke: "I went to buy some camouflage trousers yesterday but couldn't find any",
    },
    {
        joke: "Hear about the new restaurant called Karma? There’s no menu - you get what you deserve",
    },
    {
        joke: "What do you call a bee that can’t make up its mind? A maybe",
    },
    {
        joke: "England doesn't have a kidney bank, but it does have a Liverpool",
    },

    {
        joke: "I tried to sue the airline for losing my luggage. I lost my case",
    },
    {
        joke: "A police officer just knocked on my door and told me my dogs are chasing people on bikes. That’s ridiculous. My dogs don’t even own bikes",
    },
    {
        joke: "German sausage jokes are just the wurst",
    },
    {
        joke: "How does Moses make coffee? Hebrews it",
    },
    {
        joke: "I used to be indecisive; now I'm not so sure",
    },
    {
        joke: "I walked into my sister's room and tripped on a bra... It was a booby trap",
    },
    {
        joke: "What do you call the ghost of a chicken? A poultry-geist",
    },

    {
        joke: "Police were called to a daycare center where a three-year-old was resisting a rest",
    },
    {
        joke: "I'm on a seafood diet. Every time I see food, I eat it",
    },
    {
        joke: "I like European food so I decided to Russia over there because I was Hungary. After Czech'ing the menu I ordered Turkey. When I was Finnished I told the waiter 'Spain good but there is Norway I could eat another bite'",
    },
    {
        joke: "He who laughs last thinks slowest",
    },

    {
        joke: "Why are frogs so happy? They eat whatever bugs them",
    },{
        joke: "The machine at the coin factory just suddenly stopped working, with no explanation. It doesn’t make any cents",
    },
    {
        joke: "What did the grape say when it got stepped on? Nothing - but it let out a little whine",
    },

    {
        joke: "What do you call a super articulate dinosaur? A Thesaurus",
    },
    {
        joke: "Somebody stole all my lamps… I couldn’t be more de-lighted!",
    },
    {
        joke: "Why is the number six afraid of seven? Because seven ate nine",
    },
    {
        joke: "What do you call a man with no arms and no legs stuffed in your mailbox? Bill",
    },
    {
        joke: "Why aren’t dogs good dancers? Because they have two left feet!",
    },
    {
        joke: "What did one flag say to the other? Nothing, it just waved.",
    },

    {
        joke: "I lost my mood ring, and I don't know how I'm feeling about that",
    },
    {
        joke: "How was Rome split in two? With a pair of Ceasars",
    },
    {
        joke: "I'm not a doctor but I'm losing my patience",
    },
    {
        joke: "I bought a boat because it was for sail",
    },
    {
        joke: "Being vegetarian was a huge missed-steak",
    },
    {
        joke: "What would you get if you'd put a lawyer in a suit? A lawsuit",
    },
    // {
    //     joke: "",
    // },
    // {
    //     joke: "",
    // },
    // {
    //     joke: "",
    // },
    // {
    //     joke: "",
    // },
    // {
    //     joke: "",
    // },
    // {
    //     joke: "",
    // },

    // {
    //     joke: "",
    // },
    // {
    //     joke: "",
    // },
    // {
    //     joke: "",
    // },
    // {
    //     joke: "",
    // },
    // {
    //     joke: "",
    // },
    // {
    //     joke: "",
    // },
    // {
    //     joke: "",
    // },
    // {
    //     joke: "",
    // },
    // {
    //     joke: "",
    // },
    // {
    //     joke: "",
    // },

    // {
    //     joke: "",
    // },
    // {
    //     joke: "",
    // },
    // {
    //     joke: "",
    // },
   
];

exports.pun = pun;